(function () {
  const $ = (id) => document.getElementById(id);
  const send = (kind) => new Promise((resolve) => chrome.runtime.sendMessage({ kind }, (value) => resolve(value || { ok: false, error: chrome.runtime.lastError?.message })));
  const settings = () => chrome.runtime.openOptionsPage();
  $("settings").onclick = settings;
  $("userioLogin").onclick = settings;
  $("chatgptSetup").onclick = settings;
  for (const [id, kind] of [["dionImport", "dionImport"], ["dionReauth", "dionReauth"]]) {
    $(id).onclick = async () => {
      $(id).disabled = true;
      try {
        const result = await new Promise(resolve => chrome.runtime.sendMessage({kind, connectionId: $("dionConnection").value}, resolve));
        $("dionStatus").textContent = result?.ok ? (kind === "dionImport" ? "Передача подтверждена. Авторизацией управляет UserIO." : "Войдите в DION, затем передайте авторизацию.") : "Не удалось выполнить действие: " + (result?.error || "нет ответа");
      } finally { $(id).disabled = false; }
    };
  }
  async function refresh() {
    const connections = await send("connectionsList");
    const connectionItems = connections.ok && Array.isArray(connections.connections) ? connections.connections : [];
    for (const connection of connectionItems.filter(c => c.enabled)) {
      const option = document.createElement("option");
      option.value = connection.id;
      option.textContent = connection.label || connection.id;
      $("dionConnection").append(option);
    }
    $("connectionsBadge").textContent = connectionItems.length ? connectionItems.filter((item) => item.enabled).length + " включено" : "Нет подключений";
    $("connectionsSummary").textContent = connectionItems.length ? connectionItems.map((item) => (item.label || "Без названия") + " · " + (item.enabled ? "включено" : "ошибка/выкл.")).join("; ") : "VK Web · ChatGPT · Z.ai · настройте подключения";
    const user = await send("userioStatus");
    const connected = !!user.connected;
    $("userioBadge").textContent = connected ? "Выполнен вход" : "Нет входа";
    $("userioBadge").className = connected ? "good" : "muted";
    $("userioAccount").textContent = connected ? user.accountLabel : (user.error || "Войдите, чтобы подключить браузер.");
    $("userioLogin").hidden = connected;
    if (!connected) { $("chatgptBadge").textContent = "Не подключён"; return; }
    const result = await send("gptConnectionStatus");
    const accounts = result.ok && Array.isArray(result.accounts) ? result.accounts : [];
    $("chatgptBadge").textContent = accounts.length ? "Подключён" : "Не подключён";
    $("chatgptBadge").className = accounts.length ? "good" : "muted";
    const report = result.gptSyncReport;
    const matches = report && accounts.some(x => x.email && x.email.toLowerCase() === String(report.email || "").toLowerCase());
    const sync = matches ? "Обновление последних чатов: " + new Date(report.completedAt).toLocaleString() : "Синхронизация не подтверждена";
    $("chatgptAccount").textContent = result.ok ? (accounts.length ? accounts.map(x => x.email || x.name || x.slug).join(", ") + " · " + sync : "Выберите аккаунт в этом браузере.") : "Не удалось проверить состояние подключения.";
    $("chatgptSetup").textContent = accounts.length ? "Управлять" : "Подключить";
  }
  $("downloadUpdate").onclick = () => chrome.tabs.create({ url: "https://msg.bezrabotnyi.com/vk-userio-extension-mv3.zip" });
  async function refreshVersion() {
    const result = await send("extensionVersion");
    if (!result.ok) { $("versionStatus").textContent = `Версия ${result.current || chrome.runtime.getManifest().version} · не удалось проверить обновления`; return; }
    $("versionStatus").textContent = result.available ? `Версия ${result.current} · доступна ${result.latest}` : `Версия ${result.current} · обновлений нет`;
    $("downloadUpdate").hidden = !result.available;
  }
  refreshVersion();
  refresh();
})();
